%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     REPRODUCIBLE RESEARCH
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Matlab code producing figures in article:
"IMU Alignment for Smartphone-based Automotive Navigation"
Johan Wahlstr�m, Isaac Skog, Peter H�ndel

Published in:

DOI: 

Contact: {jwahlst,skog,ph}@kth.se

KTH Royal Institute of Technology, Stockholm, Sweden 2015

The code is run from "Main.m" (real data) and "Main2.m" (simulated data).